﻿// hand_extract_150124.cpp :

#include "stdafx.h"
#include "opencv2/opencv.hpp"
#include "opencv/highgui.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <thread>
#include <iostream>
using namespace std;

#define WIDTH			320
#define HEIGHT			240
#define WIDTH_RE		64
#define HEIGHT_RE		48
#define QUEUE_SIZE		10
#define PLAY_TIME		999			//sec
#define WAIT_TIME		30
#define DISPLAYNUM		4

#define VIDEO_ENABLE	
#define DISPLAY_ENABLE
#define SHAPE_ENABLE
#define MATCHING_ENABLE

// Task 1 Load Display Image Select

//#define IMAGE_FOLDER "alphabet"
//#define IMAGE_FOLDER "bio"
#define IMAGE_FOLDER "yonsei"

// Load training Data Select

//#define TRAIN_FOLDER "image_alphabet_down"
//#define TRAIN_FOLDER "image_alphabet_front"
//#define TRAIN_FOLDER "image_alphabet_up"
//#define TRAIN_FOLDER "image_word_down"
//#define TRAIN_FOLDER "image_word_front"
#define TRAIN_FOLDER "image_word_up"

// Task 3 Continuous Sine Input
//#define BIO							// 바이오사이버네틱스, 현대자동차
#define YONSEI							// 연세대학교, 연구실, 대한민국


#define POSE_SIZE		3
#define SINE_SIZE		5

#define RAD2DEG			180./M_PI
#define DEG2RAD			M_PI/180.

int fps, fps_temp = 0, curTime, startTime, priTime = 0, maxVarivation, maxTemp = 0, sec = 0, startFlag = 0;
CvCapture *capture = cvCaptureFromCAM(1);
int variCnt = 0, center_x, center_y, edgeA_x[WIDTH_RE*HEIGHT_RE], edgeA_y[WIDTH_RE*HEIGHT_RE], tempCenter_x, tempCenter_y;

char text1[100], text2[100];
int poseCnt = 0, curPose = 0, capCnt = 0;
float poseMin = 0;
CvPoint variPoint[WIDTH_RE*HEIGHT_RE], gesturePoint[1000];
IplImage *frame, *frameRe, *frameRe1, *frameReG, *queueImg[QUEUE_SIZE], *edgeImg, *varImg;
IplImage *varTempImg, *outImg, *backgndImg, *shapeImg;
IplImage *shapeTempImg, *showImg, *displayImg[50], *show2Img, *out2Img;
float pose[200][362];
int shapeFlag, threadFlag, gestureFlag, onFlag, snapFlag;
int queuePose[POSE_SIZE], tempPose, queueSine[SINE_SIZE], gestureCnt;
FILE *f, *f2, *fg;

void thread1();

int _tmain(int argc, _TCHAR* argv[]){
	threadFlag = 1;
	thread t1(&thread1);
	shapeFlag = 0;
	frame = cvRetrieveFrame(capture);
	frameRe = cvCreateImage(cvSize(WIDTH_RE, HEIGHT_RE), 8, 3);
	frameRe1 = cvCreateImage(cvSize(WIDTH_RE, HEIGHT_RE), 8, 3);
	frameReG = cvCreateImage(cvSize(WIDTH_RE, HEIGHT_RE), 8, 1);
	varImg = cvCreateImage(cvSize(WIDTH_RE, HEIGHT_RE), 8, 1);
	varTempImg = cvCreateImage(cvSize(WIDTH_RE, HEIGHT_RE), 8, 1);
	edgeImg = cvCreateImage(cvSize(WIDTH_RE, HEIGHT_RE), 8, 1);
	shapeImg = cvCreateImage(cvSize(WIDTH_RE, HEIGHT_RE), 8, 1);
	shapeTempImg = cvCreateImage(cvSize(WIDTH_RE, HEIGHT_RE), 8, 1);
	outImg = cvCreateImage(cvSize(WIDTH_RE * DISPLAYNUM, HEIGHT_RE), 8, 1);
	out2Img = cvCreateImage(cvSize(WIDTH * DISPLAYNUM, HEIGHT), 8, 1);
	showImg = cvCreateImage(cvSize(WIDTH_RE, HEIGHT_RE), 8, 1);
	show2Img = cvCreateImage(cvSize(WIDTH_RE, HEIGHT_RE), 8, 1);
	printf("Program start\n");
	// display Image Load Buffer
	printf("Load Show Image Folder\t: %s", IMAGE_FOLDER);
	poseCnt = 0;
	for (int i = 0; i < 50; i++){
		//sprintf(text1, "bio/%d.jpg", i);
		sprintf(text1, "../image/%s/%d.jpg", IMAGE_FOLDER, i);
		if ((f2 = fopen(text1, "r")) == NULL);
		else{
			displayImg[i] = cvLoadImage(text1, CV_LOAD_IMAGE_GRAYSCALE);
			poseCnt++;
			fclose(f2);
		}
	}
	printf("\tComplete : %d\n", poseCnt);
	// Pose Load buffer
	poseCnt = 0;
	printf("Load Pose Data Folder\t: %s", TRAIN_FOLDER);
	for (int i = 0; i<50; i++){
		for (int i2 = 0; i2 < 20; i2++){
			sprintf(text1, "../train/%s/%d_%d.jpg", TRAIN_FOLDER, i, i2);
			if ((f2 = fopen(text1, "r")) == NULL);
			else{
				float polarPoint[362];
				IplImage *inImg;
				inImg = cvLoadImage(text1);
				cvCvtColor(inImg, frameReG, CV_BGR2GRAY);
				center_x = 0;
				center_y = 0;
				variCnt = 0;
				for (int x = 0; x < WIDTH_RE; x++){
					for (int y = 0; y < HEIGHT_RE; y++){
						if (frameReG->imageData[(y * WIDTH_RE) + x] < 0){
							variCnt++;
							center_x += x;
							center_y += y;
							varImg->imageData[(y * WIDTH_RE) + x] = 255;
						}
						else  varImg->imageData[(y * WIDTH_RE) + x] = 0;
					}
				}
				// hand center calculataion
				if (variCnt){
					center_x = round(center_x / variCnt);
					center_y = round(center_y / variCnt);
					// Omni Hand Shape Calculatrion
					polarPoint[360] = 0;
					for (int deg = 0; deg < 360; deg++){
						float rad = deg * DEG2RAD;
						int x, y, temp[2] = { center_x, center_y };
						int flag = 0;
						polarPoint[deg] = 0;
						for (float range = 1; range < 30.; range = range + 0.1){
							x = (int)round(center_x + range*sin(rad));
							y = (int)round(center_y + range*cos(rad));
							if ((x < 1) || (x > WIDTH_RE - 1) || (y < 1) || (y > HEIGHT_RE - 1))	break;
							else if (varImg->imageData[x + (y * WIDTH_RE)]){
								temp[0] = x;
								temp[1] = y;
								polarPoint[deg] = range;
								flag = 1;
							}
						}
						if (!flag) polarPoint[deg] = 0;
						polarPoint[360] += polarPoint[deg];
					}
				}
				polarPoint[360] /= 360.;

				for (int deg = 0; deg < 361; deg++)	pose[poseCnt][deg] = polarPoint[deg];
				pose[poseCnt][361] = i;
				poseCnt++;
				fclose(f2);
			}
		}
	}

	printf("\tComplete : %d\n", poseCnt);
	printf("Cam Initialization...\n");

	cvSetCaptureProperty(capture, CV_CAP_PROP_FRAME_WIDTH, WIDTH);
	cvSetCaptureProperty(capture, CV_CAP_PROP_FRAME_HEIGHT, HEIGHT);
	cvSetCaptureProperty(capture, CV_CAP_PROP_FPS, 200);
	assert(capture);
	for (int i = 0; i < QUEUE_SIZE; i++)	queueImg[i] = cvCreateImage(cvSize(WIDTH_RE, HEIGHT_RE), 8, 1);

	onFlag = 0;

	printf("Width : %d, Height : %d\n", cvGetSize(frame).width, cvGetSize(frame).height);

#ifdef VIDEO_ENABLE
	for (int i = 0; i < 50; i++){
		sprintf(text1, "../%02d_IR_Original.avi", i);
		sprintf(text2, "../%02d_IR_Out.avi", i);
		if ((f2 = fopen(text1, "r")) == NULL) break;
		fclose(f2);
	}
	CvVideoWriter * writer1 = cvCreateVideoWriter(text1, CV_FOURCC('M', 'J', 'P', 'G'), 150, cvSize(WIDTH, HEIGHT), 1);
	CvVideoWriter * writer2 = cvCreateVideoWriter(text2, CV_FOURCC('M', 'J', 'P', 'G'), 150, cvSize(WIDTH_RE * DISPLAYNUM, HEIGHT_RE), 0);
#endif

	startTime = time(NULL);
	curTime = startTime;
	while (sec < PLAY_TIME) {

		// Resize And Gray CVT
		cvGrabFrame(capture);
		frame = cvRetrieveFrame(capture);
		cvResize(frame, frameRe);
		cvCvtColor(frameRe, frameReG, CV_BGR2GRAY);

		// Queue Input
		for (int f = 0; f < QUEUE_SIZE - 1; f++) cvCopy(queueImg[(QUEUE_SIZE - 2) - f], queueImg[(QUEUE_SIZE - 1) - f]);
		cvCopy(frameReG, queueImg[0]);
		// fps Calc  
		fps_temp++;
		sec = curTime - startTime;
		curTime = time(NULL);
		if (curTime != priTime){
			fps = fps_temp;
			fps_temp = 0;
		}
		priTime = curTime;
		maxVarivation = maxTemp;
		maxTemp = 0;
		center_x = 0;
		center_y = 0;
		variCnt = 0;
		for (int x = 0; x < WIDTH_RE; x++){
			for (int y = 0; y < HEIGHT_RE; y++){
				// Variation display
				long variation = 0;
				int mean = 0, point = (y*WIDTH_RE) + x;
				int temp;
				for (int i = 0; i < QUEUE_SIZE; i++)		mean += (unsigned char)(queueImg[i]->imageData[point]);
				mean = mean / QUEUE_SIZE;
				for (int i = 0; i < QUEUE_SIZE; i++) {
					temp = (int)((unsigned char)(queueImg[i]->imageData[point])) - mean;
					variation += temp *  temp;
				}
				variation = variation / QUEUE_SIZE;
				if (variation > 150){
					variPoint[variCnt].x = x;
					variPoint[variCnt].y = y;
					center_x += x;
					center_y += y;
					variCnt++;
					varImg->imageData[point] = 255;
				}
				else varImg->imageData[point] = 0;
				if (maxTemp < variation) maxTemp = variation;
			}
		}
		if (fps_temp % 20 == 0){
			printf("\rfps:%d\t sec:%d\t", fps, sec);
			// hand center calculataion
			if (variCnt > 50 && !shapeFlag && sec > 2){
				tempCenter_x = center_x / variCnt;
				tempCenter_y = center_y / variCnt;
				cvCopy(varImg, varTempImg);
				shapeFlag = 1;
				onFlag = 1;
			}
			else if (variCnt < 50){
				cvCopy(displayImg[0], showImg);
				curPose = 0;
			}
		}

#ifdef DISPLAY_ENABLE
		for (int i = 0; i < gestureCnt - 1; i++) cvLine(varImg, gesturePoint[i], gesturePoint[i + 1], CV_RGB(100, 100, 100));
		for (int i = 0; i < DISPLAYNUM; i++){
			int point[2];
			for (int x = 0; x < WIDTH_RE; x++){
				for (int y = 0; y < HEIGHT_RE; y++){
					point[0] = y*WIDTH_RE * DISPLAYNUM + x + i*WIDTH_RE;
					point[1] = y*WIDTH_RE + x;
					switch (i){
					case 0: outImg->imageData[point[0]] = frameReG->imageData[point[1]]; break;
					case 1: outImg->imageData[point[0]] = varImg->imageData[point[1]]; break;
					case 2: outImg->imageData[point[0]] = showImg->imageData[point[1]]; break;
					case 3: outImg->imageData[point[0]] = show2Img->imageData[point[1]]; break;
					}
				}
			}
		}
		if (snapFlag){
			struct tm *temp_time;
			time_t timer;
			timer = time(NULL);
			temp_time = localtime(&timer);
			sprintf(text1, "../IR_%03d%02d%02d%02d.jpg", temp_time->tm_yday, temp_time->tm_hour, temp_time->tm_min, temp_time->tm_sec);
			cvSaveImage(text1, outImg);
			printf("%s", text1);
			snapFlag = 0;
		}
		if (onFlag){
#ifdef VIDEO_ENABLE
			cvWriteFrame(writer1, frame);
			cvWriteFrame(writer2, outImg);
#endif
			if (fps_temp % 20 == 0){

				cvResize(outImg, out2Img);
				cvShowImage("Simulation", out2Img);
				switch (cvWaitKey(WAIT_TIME)){
				case 'p':
					printf("shape_%d.jpg", capCnt);
					sprintf(text1, "shape_%d.jpg", capCnt++);
					cvSaveImage(text1, varImg);
					break;
				case 'q':
					curTime = startTime + PLAY_TIME;
					break;
				}
			}
		}
#endif
	}

#ifdef VIDEO_ENABLE
	cvReleaseVideoWriter(&writer1);
	cvReleaseVideoWriter(&writer2);
#endif
	threadFlag = 0;
	t1.join();
	cvReleaseCapture(&capture);

	cvDestroyWindow("Simulation");
	return 0;
}


void thread1(){
	while (threadFlag){
		if (shapeFlag){
			float polarPoint[362];
			for (int i = 0; i < WIDTH_RE * HEIGHT_RE; i++)  shapeTempImg->imageData[i] = 0;
			// Omni Hand Shape Calculatrion
			polarPoint[360] = 0;
			for (int deg = 0; deg < 360; deg += 1){
				float rad = deg * DEG2RAD;
				int x, y, temp[2] = { tempCenter_x, tempCenter_y };
				int flag = 0;
				polarPoint[deg] = 0;
				for (float range = 1; range < 30; range += 0.1){
					x = round(tempCenter_x + range*sin(rad));
					y = round(tempCenter_y + range*cos(rad));
					if ((x < 1) || (x > WIDTH_RE - 1) || (y < 1) || (y > HEIGHT_RE - 1))	break;
					else if (varImg->imageData[x + (y * WIDTH_RE)]){
						temp[0] = x;
						temp[1] = y;
						polarPoint[deg] = range;
						flag = 1;
					}
				}
				if (!flag) polarPoint[deg] = 0;
				polarPoint[360] += polarPoint[deg];
			}
			cvCopy(shapeTempImg, shapeImg);

			polarPoint[360] /= 360.;
			poseMin = 1000.;
			for (int cnt = 0; cnt < poseCnt - 1; cnt++){
				int deg2 = 0, trueCnt = 0;
				float temp;
				float mean = 0;
				float polarWindow[360];
				float ratio = pose[cnt][360] / polarPoint[360];
				for (int deg = 0; deg < 360; deg++)	polarWindow[deg] = polarPoint[deg] * ratio;
				for (int rotate = -30; rotate < 30; rotate++){
					trueCnt = 0;
					mean = 0;
					for (int deg = 0; deg < 360; deg += 1){
						deg2 = rotate + deg;
						if (deg2 >= 360) deg2 -= 360;
						if (pose[cnt][deg2]){
							temp = polarWindow[deg] - pose[cnt][deg2];
							temp = abs(temp);
							mean += temp;
							trueCnt++;

						}
					}
					mean = mean / trueCnt;
					if (poseMin > mean) {
						poseMin = mean;
						tempPose = (int)pose[cnt][361];
					}
				}
			}
			if (poseMin > 20) tempPose = 0;
			for (int i = 0; i < POSE_SIZE - 1; i++)	queuePose[POSE_SIZE - 1 - i] = queuePose[POSE_SIZE - 2 - i];
			queuePose[0] = tempPose;
			for (int i = 0; i < POSE_SIZE; i++){
				if (tempPose != queuePose[i]) break;
				if (i == POSE_SIZE - 1){
					curPose = tempPose;
					if (queueSine[0] != curPose){
						for (int k = 0; k < SINE_SIZE - 1; k++)	queueSine[SINE_SIZE - 1 - k] = queueSine[SINE_SIZE - 2 - k];
						queueSine[0] = curPose;
						if (curPose)		snapFlag = 1;

#ifdef BIO
						if (queueSine[1] == 1 && queueSine[0] == 10)		cvCopy(displayImg[21], show2Img);
						else if (queueSine[1] == 2 && queueSine[0] == 11)	cvCopy(displayImg[22], show2Img);
						else if (queueSine[1] == 2 && queueSine[0] == 12)	cvCopy(displayImg[23], show2Img);
						else if (queueSine[1] == 3 && queueSine[0] == 10)	cvCopy(displayImg[24], show2Img);
						else if (queueSine[1] == 1 && queueSine[0] == 13)	cvCopy(displayImg[26], show2Img);
						else if (queueSine[1] == 4 && queueSine[0] == 14)	cvCopy(displayImg[27], show2Img);
						else if (queueSine[1] == 5 && queueSine[0] == 11)	cvCopy(displayImg[28], show2Img);
						else if (queueSine[2] == 5 && queueSine[1] == 11 && queueSine[0] == 18) cvCopy(displayImg[29], show2Img);
						else if (queueSine[1] == 3 && queueSine[0] == 15)	cvCopy(displayImg[30], show2Img);
						else if (queueSine[1] == 6 && queueSine[0] == 16)	cvCopy(displayImg[31], show2Img);
						else if (queueSine[2] == 6 && queueSine[1] == 16 && queueSine[0] == 4) cvCopy(displayImg[32], show2Img);
						else if (queueSine[1] == 7 && queueSine[0] == 17)	cvCopy(displayImg[33], show2Img);
						else if (queueSine[1] == 8 && queueSine[0] == 10)	cvCopy(displayImg[34], show2Img);
						else if (queueSine[1] == 7 && queueSine[0] == 12)	cvCopy(displayImg[35], show2Img);
						else if (queueSine[2] == 7 && queueSine[1] == 12 && queueSine[0] == 2) cvCopy(displayImg[36], show2Img);
						else if (queueSine[1] == 9 && queueSine[0] == 10)	cvCopy(displayImg[37], show2Img);
#endif
#ifdef YONSEI
						if (queueSine[1] == 1 && queueSine[0] == 8)			cvCopy(displayImg[21], show2Img);
						else if (queueSine[2] == 1 && queueSine[1] == 8 && queueSine[0] == 2) cvCopy(displayImg[22], show2Img);
						else if (queueSine[1] == 3 && queueSine[0] == 9)	cvCopy(displayImg[23], show2Img);
						else if (queueSine[1] == 4 && queueSine[0] == 10)	cvCopy(displayImg[24], show2Img);
						else if (queueSine[1] == 5 && queueSine[0] == 11)	cvCopy(displayImg[25], show2Img);
						else if (queueSine[2] == 5 && queueSine[1] == 11 && queueSine[0] == 6) cvCopy(displayImg[26], show2Img);
						else if (queueSine[1] == 6 && queueSine[0] == 12)	cvCopy(displayImg[27], show2Img);
						else if (queueSine[1] == 6 && queueSine[0] == 13)	cvCopy(displayImg[28], show2Img);
						else if (queueSine[1] == 3 && queueSine[0] == 14)	cvCopy(displayImg[29], show2Img);
						else if (queueSine[2] == 3 && queueSine[1] == 14 && queueSine[0] == 7) cvCopy(displayImg[30], show2Img);
						else if (queueSine[2] == 5 && queueSine[1] == 11 && queueSine[0] == 2) cvCopy(displayImg[31], show2Img);
						else if (queueSine[1] == 15 && queueSine[0] == 14)	cvCopy(displayImg[32], show2Img);
						else if (queueSine[2] == 15 && queueSine[1] == 14 && queueSine[0] == 2) cvCopy(displayImg[33], show2Img);
						else if (queueSine[2] == 6 && queueSine[1] == 13 && queueSine[0] == 6) cvCopy(displayImg[34], show2Img);
#endif
						printf("\r\t\t\t Pose Num : %2d %2d %2d %2d %2d\n", queueSine[0], queueSine[1], queueSine[2], queueSine[3], queueSine[4]);
					}
					if (displayImg[curPose] != NULL) cvCopy(displayImg[curPose], showImg);
					else cvCopy(displayImg[0], showImg);
				}
			}
			printf("pose:%d\tMin:%.2f\t", tempPose, poseMin);
			shapeFlag = 0;
		}
	}
}

